#!/bin/bash

# Activate the virtual environment
source /home/yaswanth/codes/testing_ws/.venv/bin/activate

# Run the Python scripts in the background and capture their PIDs
python3 /home/yaswanth/ros2_ws/src/corbis/corbis/gui_v2.py 